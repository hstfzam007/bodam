# BÀN GIAO DỰ ÁN BỘ ĐÀM INTERNET CHO CODEX

## Mục tiêu

Tiếp tục phát triển hệ thống bộ đàm Internet gồm:

- Web PC chạy trên trình duyệt.
- Realtime server chạy trên PC Linux Mint.
- Web Hosting BKHOST cPanel dùng cho website, PHP API, MySQL và lịch sử.
- ESP32-S3, màn hình 1.83 inch, **1 microphone**.
- Không dùng Docker.
- Tên miền chính: `https://weddingngocthang.online/`
- Realtime dự kiến: `wss://radio.weddingngocthang.online/ws`
- Kết nối PC Linux Mint ra Internet bằng Cloudflare Tunnel.

## Trạng thái tài liệu

Gói này là **bộ bàn giao và mã khung**, không phải sản phẩm production đã hoàn thành.

Thư mục `07_LEGACY_MVP` chứa mã MVP cũ. Codex phải kiểm tra lại toàn bộ trước khi tái sử dụng. Không được tuyên bố audio, LCD, codec hoặc pinout hoạt động nếu chưa build và thử trên bo thật.

## Trình tự bắt buộc

1. Đọc `01_REQUIREMENTS/PROJECT_BRIEF.md`.
2. Đọc `01_REQUIREMENTS/ACCEPTANCE_CRITERIA.md`.
3. Đọc `02_ARCHITECTURE/SYSTEM_ARCHITECTURE.md`.
4. Đọc `03_PROTOCOLS/REALTIME_PROTOCOL.md`.
5. Đọc `04_DEPLOYMENT/LINUX_MINT_AND_BKHOST.md`.
6. Đọc `05_CODEX_PROMPTS/MASTER_PROMPT.md`.
7. Kiểm tra mã trong `07_LEGACY_MVP`.
8. Lập kế hoạch và chờ người dùng nhập `KE_HOACH_DUOC_DUYET`.
9. Chỉ sau khi được duyệt mới bắt đầu sửa hoặc tạo mã.

## Giới hạn an toàn

- Không dùng Docker.
- Không tự chạy lệnh `sudo`.
- Không thay DNS, Cloudflare, firewall, systemd hoặc cPanel khi chưa được xác nhận.
- Không xóa file ngoài thư mục dự án.
- Không ghi token, mật khẩu hoặc khóa bí mật vào Git.
- Mọi thay đổi phải có build/test hoặc ghi rõ chưa kiểm chứng.
