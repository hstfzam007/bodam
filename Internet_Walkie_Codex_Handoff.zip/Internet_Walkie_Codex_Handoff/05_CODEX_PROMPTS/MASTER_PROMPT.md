# MASTER PROMPT CHO CODEX

Bạn đang tiếp quản dự án `Internet Walkie-Talkie`.

Hãy đọc lần lượt:

1. `00_START_HERE/README_FIRST.md`
2. `01_REQUIREMENTS/PROJECT_BRIEF.md`
3. `01_REQUIREMENTS/ACCEPTANCE_CRITERIA.md`
4. `02_ARCHITECTURE/SYSTEM_ARCHITECTURE.md`
5. `03_PROTOCOLS/REALTIME_PROTOCOL.md`
6. `04_DEPLOYMENT/LINUX_MINT_AND_BKHOST.md`
7. Toàn bộ mã trong `07_LEGACY_MVP`
8. Sơ đồ phần cứng trong `06_SOURCE_REFERENCES/D-Solution.pdf`

Yêu cầu làm việc:

- Không dùng Docker.
- Trước tiên chỉ kiểm tra môi trường bằng lệnh không cần sudo.
- Đánh giá mã legacy: phần nào tái sử dụng được, phần nào cần bỏ.
- Xác định các điểm chưa đủ dữ liệu, đặc biệt LCD, audio codec và pinout.
- Lập kế hoạch theo module.
- Chưa viết code.
- Chờ người dùng nhập chính xác `KE_HOACH_DUOC_DUYET`.

Sau khi được duyệt:

- Làm từng giai đoạn nhỏ.
- Mỗi giai đoạn phải build, lint và test.
- Tạo commit Git sau khi hoàn thành.
- Không tuyên bố phần cứng hoạt động nếu chưa thử bo thật.
- Mọi lệnh sudo/systemd/Cloudflare/DNS/firewall phải hỏi trước.
