# PROMPT THEO GIAI ĐOẠN

## Giai đoạn 1 — Realtime server

Tạo Node.js TypeScript server gồm `/health`, WebSocket `/ws`, schema validation, structured logging, test và `.env.example`. Chưa kết nối BKHOST thật; dùng auth provider interface và mock.

## Giai đoạn 2 — Presence và kênh

Thêm user/device auth provider, heartbeat 15 giây, offline 45 giây, membership, join/leave/switch channel và test.

## Giai đoạn 3 — PTT

Thêm channel lock, request/grant/deny/release, timeout 120 giây, cleanup khi disconnect và test race condition.

## Giai đoạn 4 — Audio relay

Thêm binary frame parser, size/rate validation, voice_session validation, relay đúng kênh, không lưu audio, test routing.

## Giai đoạn 5 — Web PC

Tạo frontend login, thiết bị, kênh, chat, PTT và test hai browser.

## Giai đoạn 6 — Linux Mint deployment

Tạo service template và Cloudflare config mẫu. Chỉ hiển thị lệnh sudo và chờ xác nhận.

## Giai đoạn 7 — ESP32-S3

ESP-IDF target esp32s3; tách board profile; trước tiên LCD/nút/network/message. Audio chỉ làm sau khi pinout và codec được xác minh.
