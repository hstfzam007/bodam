# PROJECT BRIEF — INTERNET WALKIE-TALKIE

## 1. Thành phần hệ thống

### Web PC

- Đăng nhập tài khoản.
- Gửi và nhận âm thanh PTT.
- Gửi và nhận tin nhắn.
- Lưu và xem lịch sử tin nhắn.
- Xem online/offline từng ESP32-S3.
- Gán và đổi tên từng thiết bị.
- Xem kênh hiện tại.
- Quản lý kênh và thành viên.

### ESP32-S3

- 1 microphone, âm thanh mono.
- Gửi và nhận audio trực tiếp qua Internet.
- Nhận tin nhắn và hiển thị nội dung.
- Màn hình chỉ hiển thị:
  1. Tên thiết bị.
  2. Kênh đang dùng.
  3. Nội dung tin nhắn khi nhận.
- BOOT GPIO0 làm PTT.
- Nhấn nhanh Volume Up/Down để tăng/giảm âm lượng.
- Giữ Volume Up/Down 3 giây để chuyển kênh tiếp theo/trước đó.
- Không thực hiện đồng thời short press và long press.
- Gửi heartbeat để Web hiển thị online/offline.

## 2. Hạ tầng

### BKHOST Web Hosting cPanel

Dùng cho:

- Website Web PC hoặc frontend build tĩnh.
- PHP REST API.
- MySQL/MariaDB.
- Tài khoản, thiết bị, kênh, lịch sử tin nhắn.
- Gán tên thiết bị.
- Firmware OTA kích thước nhỏ.

Không dùng cho:

- Docker.
- Server WebSocket/audio chạy lâu dài.
- Tiến trình realtime 24/7.

### PC Linux Mint

Dùng cho:

- Node.js/TypeScript realtime server.
- WebSocket Secure.
- Điều phối PTT.
- Relay audio.
- Presence realtime.
- Chạy bằng systemd.
- Public qua Cloudflare Tunnel, không cần mở cổng modem.

## 3. Địa chỉ

- Web/API: `https://weddingngocthang.online`
- Health realtime: `https://radio.weddingngocthang.online/health`
- WebSocket: `wss://radio.weddingngocthang.online/ws`

## 4. Quy tắc PTT

- Một kênh chỉ có một người nói tại một thời điểm.
- Client phải được xác thực và có quyền trong kênh.
- Phải nhận `talk_granted` mới được gửi audio.
- Audio khi chưa có quyền bị loại bỏ.
- Thả PTT phải dừng capture ngay.
- Tự nhả quyền nếu client disconnect, timeout hoặc mất heartbeat.
- Mỗi lượt nói tối đa 120 giây.

## 5. Audio MVP

- Mono.
- 16 kHz.
- PCM signed 16-bit.
- Frame 20 ms = 320 sample = 640 byte trước header.
- Truyền WebSocket binary.
- Server chỉ relay, không giải mã.
- Có sequence number, timestamp và voice_session_id.
- Client nhận có jitter buffer.
- Sau khi PCM ổn định mới cân nhắc ADPCM/Opus.

## 6. Presence

- Heartbeat 15 giây.
- Offline sau 45 giây không heartbeat.
- Web cập nhật realtime qua server Linux Mint.
- BKHOST lưu `last_seen_at` để có trạng thái dự phòng.

## 7. Tin nhắn

- UTF-8, hỗ trợ tiếng Việt.
- Có message_id.
- Có ACK đã nhận/đã hiển thị.
- Lưu lịch sử trong MySQL BKHOST.
- Tin tới khi ESP32 đang PTT được xếp hàng và hiển thị sau.

## 8. Bảo mật

- HTTPS/WSS.
- Không dùng TLS insecure ở production.
- Device token được hash trong database.
- Access token ngắn hạn.
- Kiểm tra schema và quyền cho mọi sự kiện.
- Rate limit.
- Không log token hoặc audio.
- Realtime server bind `127.0.0.1`.
