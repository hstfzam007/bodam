# TIÊU CHÍ NGHIỆM THU MVP

## Web PC

- Truy cập được bằng HTTPS.
- Đăng nhập thành công.
- Hiển thị danh sách ESP32-S3.
- Online/offline cập nhật trong tối đa 45 giây.
- Đổi tên thiết bị và thiết bị nhận tên mới.
- Tạo/chọn kênh.
- Gửi/nhận tin nhắn và xem lịch sử.
- Nhấn giữ PTT để nói.
- Hiển thị người/thiết bị đang nói.
- Không gửi audio khi chưa được cấp quyền.

## ESP32-S3

- Kết nối Wi-Fi và tự reconnect.
- Xác thực với server.
- Màn hình đúng yêu cầu tối giản.
- BOOT GPIO0 giữ để nói, thả để dừng.
- GPIO39 nhấn nhanh tăng âm lượng; giữ 3 giây chuyển kênh sau.
- GPIO40 nhấn nhanh giảm âm lượng; giữ 3 giây chuyển kênh trước.
- Không xảy ra hành động kép.
- Nhận và phát audio.
- Nhận tin nhắn tiếng Việt và gửi ACK.
- Mất mạng khi đang nói phải dừng audio và nhả quyền sau timeout.
- Chạy liên tục tối thiểu 72 giờ không treo hoặc rò bộ nhớ nghiêm trọng.

## Server realtime

- `GET /health` hoạt động.
- Xác thực user/device.
- Phân kênh đúng.
- Hai client xin nói đồng thời: chỉ một client được grant.
- Disconnect tự nhả quyền.
- Audio chỉ relay trong đúng kênh.
- Frame sai hoặc quá lớn bị từ chối.
- Test tự động pass.
