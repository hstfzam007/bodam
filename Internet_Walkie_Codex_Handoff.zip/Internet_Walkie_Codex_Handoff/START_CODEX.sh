#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

if ! command -v codex >/dev/null 2>&1; then
  echo "Chưa tìm thấy Codex CLI."
  echo "Hãy cài Codex CLI theo tài liệu chính thức, sau đó chạy lại:"
  echo "  ./START_CODEX.sh"
  exit 1
fi

if [ ! -d .git ]; then
  git init
fi

echo "Đang mở Codex trong thư mục dự án..."
echo "Yêu cầu Codex đọc: 05_CODEX_PROMPTS/MASTER_PROMPT.md"
codex
