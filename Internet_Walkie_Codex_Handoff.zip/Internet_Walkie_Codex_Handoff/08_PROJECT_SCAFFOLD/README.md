# PROJECT SCAFFOLD

Đây là cây thư mục mục tiêu để Codex phát triển. Các thư mục hiện mới là placeholder.

- `realtime-server`: Node.js TypeScript.
- `web-pc`: frontend Web PC.
- `web-hosting`: PHP API và cấu trúc upload cPanel.
- `firmware-esp32s3`: ESP-IDF.
- `deploy`: systemd và Cloudflare.
- `docs`: tài liệu kỹ thuật.
