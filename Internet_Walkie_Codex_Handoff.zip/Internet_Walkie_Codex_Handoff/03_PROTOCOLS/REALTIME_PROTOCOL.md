# GIAO THỨC REALTIME

## Endpoint

`wss://radio.weddingngocthang.online/ws`

## JSON events

- `client_auth`
- `device_auth`
- `auth_success`
- `auth_error`
- `heartbeat`
- `presence_changed`
- `join_channel`
- `leave_channel`
- `switch_channel`
- `switch_channel_result`
- `request_talk`
- `talk_granted`
- `talk_denied`
- `release_talk`
- `speaker_changed`
- `new_message`
- `message_ack`
- `server_error`

## Ví dụ request_talk

```json
{
  "type": "request_talk",
  "request_id": "req-uuid",
  "channel_id": "channel-01"
}
```

## talk_granted

```json
{
  "type": "talk_granted",
  "request_id": "req-uuid",
  "channel_id": "channel-01",
  "voice_session_id": "voice-uuid",
  "max_seconds": 120
}
```

## talk_denied

```json
{
  "type": "talk_denied",
  "request_id": "req-uuid",
  "reason": "channel_busy",
  "current_speaker": {
    "id": "esp32-0002",
    "name": "Bộ đàm Bảo vệ 02"
  }
}
```

## Binary audio frame đề xuất

Header cố định, network byte order:

```text
magic              2 bytes
version            1 byte
flags              1 byte
sequence           4 bytes
timestamp_ms       8 bytes
voice_session_id  16 bytes UUID binary
payload_length     2 bytes
payload            N bytes
```

MVP PCM 20 ms có payload 640 byte.

## Quy tắc

- Chỉ speaker có active grant được gửi frame.
- `voice_session_id` phải khớp phiên đang hoạt động.
- Sequence tăng dần.
- Frame quá kích thước bị từ chối.
- Server relay tới thành viên khác cùng kênh.
- Không lưu audio xuống đĩa.
