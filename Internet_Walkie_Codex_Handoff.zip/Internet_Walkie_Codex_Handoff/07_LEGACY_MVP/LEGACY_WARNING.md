# CẢNH BÁO MÃ LEGACY

Mã trong thư mục này là MVP cũ được tạo trước khi chốt:

- ESP32-S3.
- 1 microphone.
- BKHOST Web Hosting + PC Linux Mint realtime.
- Cloudflare Tunnel.
- Kiến trúc không Docker.

Codex phải:

1. Build và kiểm tra độc lập.
2. Không tin rằng pinout/audio/LCD đã đúng.
3. Không triển khai production nguyên trạng.
4. Chỉ tái sử dụng sau code review và test.
