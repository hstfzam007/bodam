# Web PC + Realtime Server

## Chạy nhanh

```bash
npm install
npm start
```

Mở `http://localhost:8080` trên PC. ESP32 kết nối tới:

```text
ws://DIA_CHI_IP_CUA_PC:8080/ws
```

## Chức năng MVP

- Hiển thị online/offline của từng ESP32 theo thời gian thực.
- Hiển thị tên thiết bị, mã thiết bị, kênh đang dùng và trạng thái đang nói.
- Đổi tên thiết bị từ trình duyệt.
- Gửi tin nhắn tới toàn bộ ESP32 trong một kênh.
- Lưu lịch sử tin nhắn trong RAM khi server đang chạy.
- Điều phối PTT một người nói tại một thời điểm trong mỗi kênh.
- Chuyển tiếp frame âm thanh nhị phân giữa các client cùng kênh.

## Lưu ý MVP

- Chưa có database và tài khoản đăng nhập thật.
- Khởi động lại server sẽ mất lịch sử và cấu hình tên thiết bị.
- Chưa triển khai TLS/HTTPS, phân quyền hoặc mã hóa đầu cuối.
- Phần audio web chưa phát/thu trực tiếp; server đã có đường relay binary để tích hợp tiếp.
