const state = { devices: new Map(), channels: [], messages: [] };
const $ = (id) => document.getElementById(id);
let ws;

function channelName(id) { return state.channels.find(c => c.id === id)?.name || id; }
function connect() {
  const protocol = location.protocol === 'https:' ? 'wss' : 'ws';
  ws = new WebSocket(`${protocol}://${location.host}/ws`);
  ws.onopen = () => { ws.send(JSON.stringify({ type: 'dashboard_auth' })); setStatus(true); };
  ws.onclose = () => { setStatus(false); setTimeout(connect, 2000); };
  ws.onmessage = (event) => {
    if (typeof event.data !== 'string') return;
    const msg = JSON.parse(event.data);
    if (msg.type === 'dashboard_snapshot') {
      state.channels = msg.channels || [];
      state.devices = new Map((msg.devices || []).map(d => [d.device_id, d]));
      state.messages = msg.messages || [];
      renderAll();
    } else if (msg.type === 'device_presence_changed' || msg.type === 'device_updated') {
      state.devices.set(msg.device.device_id, msg.device); renderDevices();
    } else if (msg.type === 'new_message') {
      state.messages.push(msg.message); renderMessages();
    }
  };
}
function setStatus(online) {
  $('serverStatus').textContent = online ? 'Đã kết nối' : 'Mất kết nối';
  $('serverStatus').className = `pill ${online ? 'online' : 'offline'}`;
}
function renderAll() {
  $('channelSelect').innerHTML = state.channels.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
  renderDevices(); renderMessages();
}
function renderDevices() {
  const filter = $('filterInput').value.trim().toLowerCase();
  const list = [...state.devices.values()].filter(d => d.device_name.toLowerCase().includes(filter));
  $('deviceList').innerHTML = list.length ? list.map(d => `
    <article class="device">
      <div>
        <div class="device-name"><span class="dot ${d.online ? 'on' : ''}"></span>${escapeHtml(d.device_name)}</div>
        <div class="meta">${d.online ? 'Online' : `Offline · ${formatTime(d.last_seen_at)}`} · ${escapeHtml(channelName(d.active_channel_id))}</div>
        <div class="meta">ID: ${escapeHtml(d.device_id)}${d.speaking ? ' · <span class="speaking">Đang nói</span>' : ''}</div>
      </div>
      <button onclick="openRename('${d.device_id}')">Đổi tên</button>
    </article>`).join('') : '<p>Chưa có thiết bị kết nối.</p>';
}
function renderMessages() {
  $('messageList').innerHTML = state.messages.slice().reverse().map(m => `
    <div class="message"><strong>${escapeHtml(channelName(m.channel_id))}</strong><br>${escapeHtml(m.content)}<br><time>${formatTime(m.created_at)}</time></div>`).join('') || '<p>Chưa có tin nhắn.</p>';
}
function formatTime(value) { if (!value) return ''; return new Date(value).toLocaleString('vi-VN'); }
function escapeHtml(s) { return String(s ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
window.openRename = (deviceId) => {
  const d = state.devices.get(deviceId); $('renameDeviceId').value = deviceId; $('renameDeviceName').value = d.device_name; $('renameDialog').showModal();
};
$('renameForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = $('renameDeviceId').value;
  const name = $('renameDeviceName').value.trim();
  const response = await fetch(`/api/devices/${encodeURIComponent(id)}`, { method:'PATCH', headers:{'Content-Type':'application/json'}, body:JSON.stringify({device_name:name}) });
  if (!response.ok) return alert('Không thể đổi tên thiết bị');
  $('renameDialog').close();
});
$('sendButton').addEventListener('click', async () => {
  const content = $('messageInput').value.trim(); if (!content) return;
  const response = await fetch('/api/messages', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ channel_id:$('channelSelect').value, content }) });
  if (!response.ok) return alert('Không gửi được tin nhắn');
  $('messageInput').value = '';
});
$('messageInput').addEventListener('keydown', e => { if (e.key === 'Enter') $('sendButton').click(); });
$('filterInput').addEventListener('input', renderDevices);
connect();
