'use strict';

const express = require('express');
const http = require('http');
const path = require('path');
const { WebSocketServer, WebSocket } = require('ws');

const PORT = Number(process.env.PORT || 8080);
const OFFLINE_AFTER_MS = 45_000;
const app = express();
app.use(express.json({ limit: '256kb' }));
app.use(express.static(path.join(__dirname, 'public')));

const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });

/** @type {Map<string, any>} */
const devices = new Map();
/** @type {Map<string, Set<WebSocket>>} */
const channelSockets = new Map();
/** @type {Set<WebSocket>} */
const dashboardSockets = new Set();
/** @type {Map<string, {deviceId:string, sessionId:string, grantedAt:number}>} */
const channelTalkers = new Map();
const messages = [];

const channels = [
  { id: 'channel-1', name: 'Kênh 1' },
  { id: 'channel-2', name: 'Kênh 2' },
  { id: 'channel-3', name: 'Kênh 3' }
];

function nowIso() { return new Date().toISOString(); }
function sendJson(ws, payload) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(payload));
}
function broadcastDashboard(payload) {
  for (const ws of dashboardSockets) sendJson(ws, payload);
}
function publicDevice(d) {
  return {
    device_id: d.device_id,
    device_name: d.device_name,
    active_channel_id: d.active_channel_id,
    online: Boolean(d.online),
    last_seen_at: d.last_seen_at,
    battery_level: d.battery_level ?? null,
    wifi_rssi: d.wifi_rssi ?? null,
    firmware_version: d.firmware_version ?? null,
    speaking: Boolean(d.speaking)
  };
}
function attachToChannel(ws, channelId) {
  if (ws.channelId && channelSockets.has(ws.channelId)) channelSockets.get(ws.channelId).delete(ws);
  ws.channelId = channelId;
  if (!channelSockets.has(channelId)) channelSockets.set(channelId, new Set());
  channelSockets.get(channelId).add(ws);
}
function sendInitialDashboard(ws) {
  sendJson(ws, {
    type: 'dashboard_snapshot',
    channels,
    devices: [...devices.values()].map(publicDevice),
    messages: messages.slice(-100)
  });
}
function markOffline(deviceId) {
  const d = devices.get(deviceId);
  if (!d || !d.online) return;
  d.online = false;
  d.speaking = false;
  d.last_seen_at = nowIso();
  if (channelTalkers.get(d.active_channel_id)?.deviceId === deviceId) channelTalkers.delete(d.active_channel_id);
  broadcastDashboard({ type: 'device_presence_changed', device: publicDevice(d) });
}

app.get('/api/devices', (_req, res) => res.json([...devices.values()].map(publicDevice)));
app.get('/api/channels', (_req, res) => res.json(channels));
app.get('/api/messages', (_req, res) => res.json(messages.slice(-200)));
app.patch('/api/devices/:deviceId', (req, res) => {
  const d = devices.get(req.params.deviceId);
  if (!d) return res.status(404).json({ error: 'DEVICE_NOT_FOUND' });
  const name = String(req.body.device_name || '').trim();
  if (!name || name.length > 50) return res.status(400).json({ error: 'INVALID_DEVICE_NAME' });
  d.device_name = name;
  sendJson(d.ws, { type: 'device_config_updated', device_name: name });
  broadcastDashboard({ type: 'device_updated', device: publicDevice(d) });
  res.json(publicDevice(d));
});
app.post('/api/messages', (req, res) => {
  const channelId = String(req.body.channel_id || '');
  const content = String(req.body.content || '').trim();
  if (!channels.some(c => c.id === channelId)) return res.status(400).json({ error: 'INVALID_CHANNEL' });
  if (!content || content.length > 500) return res.status(400).json({ error: 'INVALID_CONTENT' });
  const message = {
    id: `msg-${Date.now()}`,
    channel_id: channelId,
    sender_name: 'PC Web',
    content,
    created_at: nowIso()
  };
  messages.push(message);
  const peers = channelSockets.get(channelId) || [];
  for (const ws of peers) sendJson(ws, { type: 'new_message', message });
  broadcastDashboard({ type: 'new_message', message });
  res.status(201).json(message);
});

wss.on('connection', (ws) => {
  ws.role = 'unknown';
  ws.isAlive = true;
  ws.on('pong', () => { ws.isAlive = true; });

  ws.on('message', (raw, isBinary) => {
    if (isBinary) {
      if (ws.role !== 'device' || !ws.channelId) return;
      const talker = channelTalkers.get(ws.channelId);
      if (!talker || talker.deviceId !== ws.deviceId) return;
      for (const peer of channelSockets.get(ws.channelId) || []) {
        if (peer !== ws && peer.readyState === WebSocket.OPEN) peer.send(raw, { binary: true });
      }
      return;
    }

    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }

    if (msg.type === 'dashboard_auth') {
      ws.role = 'dashboard';
      dashboardSockets.add(ws);
      sendInitialDashboard(ws);
      return;
    }

    if (msg.type === 'device_auth') {
      const deviceId = String(msg.device_id || '').trim();
      if (!deviceId) return sendJson(ws, { type: 'device_auth_result', success: false });
      ws.role = 'device';
      ws.deviceId = deviceId;
      const existing = devices.get(deviceId) || {};
      const d = {
        ...existing,
        device_id: deviceId,
        device_name: existing.device_name || msg.device_name || deviceId,
        active_channel_id: existing.active_channel_id || msg.active_channel_id || channels[0].id,
        online: true,
        speaking: false,
        last_seen_at: nowIso(),
        battery_level: msg.battery_level ?? existing.battery_level ?? null,
        wifi_rssi: msg.wifi_rssi ?? existing.wifi_rssi ?? null,
        firmware_version: msg.firmware_version || existing.firmware_version || '0.1.0',
        ws
      };
      devices.set(deviceId, d);
      attachToChannel(ws, d.active_channel_id);
      sendJson(ws, {
        type: 'device_auth_result', success: true,
        device_name: d.device_name,
        active_channel_id: d.active_channel_id,
        channels
      });
      broadcastDashboard({ type: 'device_presence_changed', device: publicDevice(d) });
      return;
    }

    if (ws.role !== 'device') return;
    const d = devices.get(ws.deviceId);
    if (!d) return;
    d.last_seen_at = nowIso();
    d.online = true;

    switch (msg.type) {
      case 'device_heartbeat':
        d.battery_level = msg.battery_level ?? d.battery_level;
        d.wifi_rssi = msg.wifi_rssi ?? d.wifi_rssi;
        d.firmware_version = msg.firmware_version || d.firmware_version;
        broadcastDashboard({ type: 'device_updated', device: publicDevice(d) });
        break;
      case 'request_talk': {
        const current = channelTalkers.get(d.active_channel_id);
        if (current && current.deviceId !== d.device_id) {
          sendJson(ws, { type: 'talk_denied', reason: 'channel_busy' });
          break;
        }
        const sessionId = `voice-${Date.now()}`;
        channelTalkers.set(d.active_channel_id, { deviceId: d.device_id, sessionId, grantedAt: Date.now() });
        d.speaking = true;
        sendJson(ws, { type: 'talk_granted', session_id: sessionId });
        broadcastDashboard({ type: 'device_updated', device: publicDevice(d) });
        break;
      }
      case 'release_talk':
      case 'cancel_talk_request':
        if (channelTalkers.get(d.active_channel_id)?.deviceId === d.device_id) channelTalkers.delete(d.active_channel_id);
        d.speaking = false;
        broadcastDashboard({ type: 'device_updated', device: publicDevice(d) });
        break;
      case 'switch_channel': {
        if (d.speaking) return sendJson(ws, { type: 'switch_channel_result', success: false, reason: 'speaking' });
        const target = channels.find(c => c.id === msg.to_channel_id);
        if (!target) return sendJson(ws, { type: 'switch_channel_result', success: false, reason: 'invalid_channel' });
        d.active_channel_id = target.id;
        attachToChannel(ws, target.id);
        sendJson(ws, { type: 'switch_channel_result', success: true, channel: target });
        broadcastDashboard({ type: 'device_updated', device: publicDevice(d) });
        break;
      }
      case 'message_ack':
        break;
      default:
        break;
    }
  });

  ws.on('close', () => {
    dashboardSockets.delete(ws);
    if (ws.channelId && channelSockets.has(ws.channelId)) channelSockets.get(ws.channelId).delete(ws);
    if (ws.role === 'device' && ws.deviceId) markOffline(ws.deviceId);
  });
});

setInterval(() => {
  const now = Date.now();
  for (const d of devices.values()) {
    if (d.online && now - new Date(d.last_seen_at).getTime() > OFFLINE_AFTER_MS) markOffline(d.device_id);
  }
  for (const ws of wss.clients) {
    if (!ws.isAlive) ws.terminate();
    else { ws.isAlive = false; ws.ping(); }
  }
}, 15_000);

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Walkie MVP running at http://localhost:${PORT}`);
  console.log(`ESP32 WebSocket endpoint: ws://<PC-IP>:${PORT}/ws`);
});
