#pragma once

// ===== Wi-Fi / server: thay trước khi nạp =====
#define WIFI_SSID "YOUR_WIFI_NAME"
#define WIFI_PASSWORD "YOUR_WIFI_PASSWORD"
#define SERVER_HOST "192.168.1.100"
#define SERVER_PORT 8080
#define SERVER_PATH "/ws"

#define DEVICE_ID "DS-ESP32-000001"
#define DEFAULT_DEVICE_NAME "Bo dam 01"
#define FIRMWARE_VERSION "0.1.0"

// ===== Buttons from supplied hardware diagram =====
static constexpr int PIN_PTT_BOOT = 0;
static constexpr int PIN_VOLUME_UP = 39;
static constexpr int PIN_VOLUME_DOWN = 40;
static constexpr uint32_t BUTTON_DEBOUNCE_MS = 40;
static constexpr uint32_t CHANNEL_HOLD_MS = 3000;

// ===== LCD SPI from supplied hardware diagram =====
static constexpr int PIN_LCD_DC = 8;
static constexpr int PIN_LCD_CS = 14;
static constexpr int PIN_LCD_SCLK = 9;
static constexpr int PIN_LCD_MOSI = 10;
static constexpr int PIN_LCD_RST = 18;
static constexpr int PIN_LCD_BL = 13;
static constexpr int LCD_WIDTH = 240;
static constexpr int LCD_HEIGHT = 284;

// ===== I2S from supplied hardware diagram =====
static constexpr int PIN_MIC_DIN = 6;
static constexpr int PIN_MIC_BCLK = 5;
static constexpr int PIN_MIC_WS = 4;
static constexpr int PIN_SPK_DOUT = 7;
static constexpr int PIN_SPK_BCLK = 15;
static constexpr int PIN_SPK_LRCK = 16;

static constexpr uint32_t AUDIO_SAMPLE_RATE = 16000;
static constexpr size_t AUDIO_FRAME_SAMPLES = 320; // 20 ms at 16 kHz
static constexpr uint32_t HEARTBEAT_MS = 15000;
static constexpr uint32_t MESSAGE_DISPLAY_MS = 10000;
