#include <Arduino.h>
#include <WiFi.h>
#include <WebSocketsClient.h>
#include <ArduinoJson.h>
#include <Preferences.h>
#include <driver/i2s.h>
#include <Arduino_GFX_Library.h>
#include "config.h"

WebSocketsClient webSocket;
Preferences prefs;

Arduino_DataBus *bus = new Arduino_ESP32SPI(PIN_LCD_DC, PIN_LCD_CS, PIN_LCD_SCLK, PIN_LCD_MOSI);
Arduino_GFX *gfx = new Arduino_ST7789(bus, PIN_LCD_RST, 0, true, LCD_WIDTH, LCD_HEIGHT);

struct Channel { String id; String name; };
Channel channels[16];
size_t channelCount = 0;
int activeChannelIndex = 0;
String deviceName = DEFAULT_DEVICE_NAME;
String currentMessage;
uint32_t messageUntil = 0;

bool serverOnline = false;
bool pttPressed = false;
bool talkGranted = false;
bool audioInitialized = false;
uint32_t lastHeartbeat = 0;

struct ButtonState {
  int pin;
  bool stablePressed = false;
  bool rawPressed = false;
  bool longTriggered = false;
  uint32_t changedAt = 0;
  uint32_t pressedAt = 0;
};
ButtonState volUp{PIN_VOLUME_UP}, volDown{PIN_VOLUME_DOWN};

static void drawHome();
static void drawMessage(const String &text);
static void sendJson(const JsonDocument &doc);
static void requestChannelDelta(int delta);

bool codecInitHook() {
  // TODO: cấu hình ES8311/ES7210 qua I2C theo schematic/driver chính xác của bo mạch.
  // Trả true để cho phép kiểm thử I2S trực tiếp. Với bo codec thật, thay bằng driver codec.
  return true;
}

bool initAudio() {
  if (!codecInitHook()) return false;

  i2s_config_t micCfg{};
  micCfg.mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX);
  micCfg.sample_rate = AUDIO_SAMPLE_RATE;
  micCfg.bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT;
  micCfg.channel_format = I2S_CHANNEL_FMT_ONLY_LEFT;
  micCfg.communication_format = I2S_COMM_FORMAT_STAND_I2S;
  micCfg.intr_alloc_flags = ESP_INTR_FLAG_LEVEL1;
  micCfg.dma_buf_count = 6;
  micCfg.dma_buf_len = AUDIO_FRAME_SAMPLES;
  micCfg.use_apll = false;
  micCfg.tx_desc_auto_clear = false;
  micCfg.fixed_mclk = 0;
  i2s_pin_config_t micPins{};
  micPins.bck_io_num = PIN_MIC_BCLK;
  micPins.ws_io_num = PIN_MIC_WS;
  micPins.data_out_num = I2S_PIN_NO_CHANGE;
  micPins.data_in_num = PIN_MIC_DIN;

  i2s_config_t spkCfg{};
  spkCfg.mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX);
  spkCfg.sample_rate = AUDIO_SAMPLE_RATE;
  spkCfg.bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT;
  spkCfg.channel_format = I2S_CHANNEL_FMT_ONLY_LEFT;
  spkCfg.communication_format = I2S_COMM_FORMAT_STAND_I2S;
  spkCfg.intr_alloc_flags = ESP_INTR_FLAG_LEVEL1;
  spkCfg.dma_buf_count = 6;
  spkCfg.dma_buf_len = AUDIO_FRAME_SAMPLES;
  spkCfg.use_apll = false;
  spkCfg.tx_desc_auto_clear = true;
  spkCfg.fixed_mclk = 0;
  i2s_pin_config_t spkPins{};
  spkPins.bck_io_num = PIN_SPK_BCLK;
  spkPins.ws_io_num = PIN_SPK_LRCK;
  spkPins.data_out_num = PIN_SPK_DOUT;
  spkPins.data_in_num = I2S_PIN_NO_CHANGE;

  esp_err_t err = i2s_driver_install(I2S_NUM_0, &micCfg, 0, nullptr);
  if (err != ESP_OK) return false;
  err = i2s_set_pin(I2S_NUM_0, &micPins);
  if (err != ESP_OK) return false;
  err = i2s_driver_install(I2S_NUM_1, &spkCfg, 0, nullptr);
  if (err != ESP_OK) return false;
  err = i2s_set_pin(I2S_NUM_1, &spkPins);
  return err == ESP_OK;
}

void initDisplay() {
  pinMode(PIN_LCD_BL, OUTPUT);
  digitalWrite(PIN_LCD_BL, HIGH);
  gfx->begin();
  gfx->fillScreen(BLACK);
  gfx->setTextWrap(true);
  drawHome();
}

void drawCentered(const String &text, int y, uint8_t size) {
  gfx->setTextSize(size);
  gfx->setTextColor(WHITE, BLACK);
  int16_t x1, y1;
  uint16_t w, h;
  gfx->getTextBounds(text, 0, y, &x1, &y1, &w, &h);
  int x = max(4, (LCD_WIDTH - (int)w) / 2);
  gfx->setCursor(x, y);
  gfx->print(text);
}

void drawHome() {
  gfx->fillScreen(BLACK);
  drawCentered(deviceName, 55, 2);
  String channel = channelCount ? channels[activeChannelIndex].name : "Chua co kenh";
  drawCentered("KENH DANG DUNG", 145, 2);
  drawCentered(channel, 185, 2);
}

void drawMessage(const String &text) {
  gfx->fillScreen(BLACK);
  drawCentered("TIN NHAN", 20, 2);
  gfx->drawFastHLine(10, 55, LCD_WIDTH - 20, WHITE);
  gfx->setTextSize(2);
  gfx->setTextColor(WHITE, BLACK);
  gfx->setCursor(12, 75);
  gfx->println(text);
}

void sendJson(const JsonDocument &doc) {
  String out;
  serializeJson(doc, out);
  webSocket.sendTXT(out);
}

void sendDeviceAuth() {
  JsonDocument doc;
  doc["type"] = "device_auth";
  doc["device_id"] = DEVICE_ID;
  doc["device_name"] = deviceName;
  doc["firmware_version"] = FIRMWARE_VERSION;
  doc["active_channel_id"] = channelCount ? channels[activeChannelIndex].id : "channel-1";
  doc["wifi_rssi"] = WiFi.RSSI();
  sendJson(doc);
}

void sendHeartbeat() {
  JsonDocument doc;
  doc["type"] = "device_heartbeat";
  doc["device_id"] = DEVICE_ID;
  doc["active_channel_id"] = channelCount ? channels[activeChannelIndex].id : "";
  doc["wifi_rssi"] = WiFi.RSSI();
  doc["firmware_version"] = FIRMWARE_VERSION;
  doc["uptime_seconds"] = millis() / 1000;
  sendJson(doc);
}

void handleText(uint8_t *payload, size_t length) {
  JsonDocument doc;
  if (deserializeJson(doc, payload, length)) return;
  const String type = doc["type"] | "";

  if (type == "device_auth_result" && doc["success"] == true) {
    serverOnline = true;
    deviceName = String((const char*)doc["device_name"] | deviceName.c_str());
    prefs.putString("device_name", deviceName);
    channelCount = 0;
    for (JsonObject c : doc["channels"].as<JsonArray>()) {
      if (channelCount >= 16) break;
      channels[channelCount].id = String((const char*)c["id"] | "");
      channels[channelCount].name = String((const char*)c["name"] | "");
      channelCount++;
    }
    String activeId = String((const char*)doc["active_channel_id"] | "");
    for (size_t i = 0; i < channelCount; i++) if (channels[i].id == activeId) activeChannelIndex = i;
    prefs.putInt("channel_idx", activeChannelIndex);
    drawHome();
  } else if (type == "device_config_updated") {
    deviceName = String((const char*)doc["device_name"] | deviceName.c_str());
    prefs.putString("device_name", deviceName);
    if (!currentMessage.length()) drawHome();
  } else if (type == "talk_granted") {
    if (pttPressed) talkGranted = true;
    else {
      JsonDocument release;
      release["type"] = "release_talk";
      sendJson(release);
    }
  } else if (type == "talk_denied") {
    talkGranted = false;
  } else if (type == "switch_channel_result" && doc["success"] == true) {
    String id = String((const char*)doc["channel"]["id"] | "");
    for (size_t i = 0; i < channelCount; i++) if (channels[i].id == id) activeChannelIndex = i;
    prefs.putInt("channel_idx", activeChannelIndex);
    drawHome();
  } else if (type == "new_message") {
    currentMessage = String((const char*)doc["message"]["content"] | "");
    messageUntil = millis() + MESSAGE_DISPLAY_MS;
    if (!pttPressed) drawMessage(currentMessage);
    JsonDocument ack;
    ack["type"] = "message_ack";
    ack["message_id"] = doc["message"]["id"];
    ack["status"] = "displayed";
    sendJson(ack);
  }
}

void webSocketEvent(WStype_t type, uint8_t *payload, size_t length) {
  switch (type) {
    case WStype_CONNECTED: sendDeviceAuth(); break;
    case WStype_DISCONNECTED: serverOnline = false; talkGranted = false; break;
    case WStype_TEXT: handleText(payload, length); break;
    case WStype_BIN: {
      if (!audioInitialized || talkGranted) break;
      size_t written = 0;
      i2s_write(I2S_NUM_1, payload, length, &written, portMAX_DELAY);
      break;
    }
    default: break;
  }
}

void onPttPressed() {
  if (!serverOnline || !channelCount) return;
  pttPressed = true;
  JsonDocument doc;
  doc["type"] = "request_talk";
  doc["channel_id"] = channels[activeChannelIndex].id;
  sendJson(doc);
}

void onPttReleased() {
  pttPressed = false;
  talkGranted = false;
  JsonDocument doc;
  doc["type"] = "release_talk";
  sendJson(doc);
  if (currentMessage.length() && millis() < messageUntil) drawMessage(currentMessage); else drawHome();
}

void requestChannelDelta(int delta) {
  if (!serverOnline || talkGranted || channelCount == 0) return;
  int target = (activeChannelIndex + delta + (int)channelCount) % (int)channelCount;
  JsonDocument doc;
  doc["type"] = "switch_channel";
  doc["from_channel_id"] = channels[activeChannelIndex].id;
  doc["to_channel_id"] = channels[target].id;
  sendJson(doc);
}

void adjustVolume(int delta) {
  int value = prefs.getInt("volume", 6);
  value = constrain(value + delta, 0, 10);
  prefs.putInt("volume", value);
  // TODO: áp dụng mức volume vào ES8311/NS4150 sau khi tích hợp driver codec.
}

void processVolumeButton(ButtonState &b, int shortDelta, int channelDelta) {
  bool raw = digitalRead(b.pin) == LOW;
  uint32_t now = millis();
  if (raw != b.rawPressed) { b.rawPressed = raw; b.changedAt = now; }
  if (now - b.changedAt < BUTTON_DEBOUNCE_MS) return;

  if (raw != b.stablePressed) {
    b.stablePressed = raw;
    if (raw) { b.pressedAt = now; b.longTriggered = false; }
    else {
      if (!b.longTriggered) adjustVolume(shortDelta);
      b.longTriggered = false;
    }
  }
  if (b.stablePressed && !b.longTriggered && now - b.pressedAt >= CHANNEL_HOLD_MS) {
    b.longTriggered = true;
    requestChannelDelta(channelDelta);
  }
}

void captureAndSendAudio() {
  if (!audioInitialized || !talkGranted || !pttPressed) return;
  static int16_t frame[AUDIO_FRAME_SAMPLES];
  size_t bytesRead = 0;
  esp_err_t err = i2s_read(I2S_NUM_0, frame, sizeof(frame), &bytesRead, 0);
  if (err == ESP_OK && bytesRead > 0) webSocket.sendBIN((uint8_t*)frame, bytesRead);
}

void setup() {
  Serial.begin(115200);
  pinMode(PIN_PTT_BOOT, INPUT_PULLUP);
  pinMode(PIN_VOLUME_UP, INPUT_PULLUP);
  pinMode(PIN_VOLUME_DOWN, INPUT_PULLUP);
  prefs.begin("walkie", false);
  deviceName = prefs.getString("device_name", DEFAULT_DEVICE_NAME);
  activeChannelIndex = prefs.getInt("channel_idx", 0);
  initDisplay();
  audioInitialized = initAudio();

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  while (WiFi.status() != WL_CONNECTED) { delay(300); Serial.print('.'); }
  Serial.printf("\nIP: %s\n", WiFi.localIP().toString().c_str());

  webSocket.begin(SERVER_HOST, SERVER_PORT, SERVER_PATH);
  webSocket.onEvent(webSocketEvent);
  webSocket.setReconnectInterval(3000);
  webSocket.enableHeartbeat(15000, 3000, 2);
}

void loop() {
  webSocket.loop();
  uint32_t now = millis();

  static bool lastPtt = false;
  bool currentPtt = digitalRead(PIN_PTT_BOOT) == LOW;
  if (currentPtt != lastPtt) {
    delay(BUTTON_DEBOUNCE_MS);
    currentPtt = digitalRead(PIN_PTT_BOOT) == LOW;
    if (currentPtt != lastPtt) {
      lastPtt = currentPtt;
      if (currentPtt) onPttPressed(); else onPttReleased();
    }
  }

  processVolumeButton(volUp, +1, +1);
  processVolumeButton(volDown, -1, -1);
  captureAndSendAudio();

  if (serverOnline && now - lastHeartbeat >= HEARTBEAT_MS) {
    lastHeartbeat = now;
    sendHeartbeat();
  }
  if (currentMessage.length() && (int32_t)(now - messageUntil) >= 0) {
    currentMessage = "";
    if (!pttPressed) drawHome();
  }
  delay(1);
}
