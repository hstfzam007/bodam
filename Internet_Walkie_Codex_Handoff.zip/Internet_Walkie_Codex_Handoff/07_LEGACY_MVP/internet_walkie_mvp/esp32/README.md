# ESP32 Internet Walkie MVP

## Phần cứng đã ánh xạ

- BOOT GPIO0: PTT, giữ để nói và thả để dừng.
- Volume Up GPIO39: nhấn nhả tăng âm lượng; giữ 3 giây chuyển kênh kế tiếp.
- Volume Down GPIO40: nhấn nhả giảm âm lượng; giữ 3 giây chuyển kênh trước.
- LCD SPI: DC 8, CS 14, SCLK 9, MOSI 10, RST 18, BL 13.
- Microphone I2S: DIN 6, BCLK 5, WS 4.
- Speaker I2S: DOUT 7, BCLK 15, LRCK 16.

## Cấu hình

Sửa `include/config.h`:

```cpp
#define WIFI_SSID "..."
#define WIFI_PASSWORD "..."
#define SERVER_HOST "IP_CUA_PC_CHAY_SERVER"
```

## Build và nạp

Cài VS Code + PlatformIO, mở thư mục `esp32`, sau đó:

```bash
pio run
pio run --target upload
pio device monitor
```

## Màn hình ESP32

Chỉ hiển thị:

- Tên thiết bị.
- Kênh đang dùng.
- Nội dung tin nhắn khi nhận được.

## Điểm cần hoàn thiện trên bo thật

PDF cung cấp bảng chân nhưng chưa cung cấp schematic đầy đủ và chuỗi lệnh khởi tạo codec. Hàm `codecInitHook()` đang là điểm móc để tích hợp ES8311/ES7210/NS4150. Trước khi có driver codec đúng, thu/phát âm thanh có thể chưa hoạt động trên bo sản phẩm dù dự án biên dịch được.

Driver màn hình hiện chọn ST7789. Nếu bo thực tế dùng NV3030B thì cần thay lớp panel/driver theo IC màn hình thực tế.
