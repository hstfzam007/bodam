# Internet Walkie MVP – ESP32 + Web PC

Gói này gồm:

- `web-server/`: giao diện web PC và máy chủ WebSocket realtime.
- `esp32/`: firmware PlatformIO cho thiết bị ESP32.

## Thứ tự chạy

1. Trên PC vào `web-server`, chạy `npm install` và `npm start`.
2. Xác định IP LAN của PC, ví dụ `192.168.1.100`.
3. Điền Wi-Fi và IP server vào `esp32/include/config.h`.
4. Build/nạp firmware bằng PlatformIO.
5. Mở `http://localhost:8080` để xem thiết bị online, đổi tên và gửi tin nhắn.

## Phạm vi phiên bản 0.1.0

Đã có luồng quản lý thiết bị, heartbeat online/offline, đổi tên, kênh, tin nhắn, PTT lock và relay PCM nhị phân. Chưa có tài khoản đăng nhập, database bền vững, HTTPS, OTA và codec phần cứng hoàn chỉnh.
