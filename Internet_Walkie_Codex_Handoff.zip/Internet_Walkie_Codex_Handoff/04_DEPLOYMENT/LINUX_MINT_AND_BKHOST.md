# TRIỂN KHAI KHÔNG DOCKER

## BKHOST Web Hosting

- PHP 8.x.
- MySQL/MariaDB.
- Frontend tĩnh.
- Cấu hình qua cPanel.
- Không chạy Docker.
- Không giả định có Node.js daemon/WebSocket.

## Linux Mint

- Node.js LTS.
- Realtime server bind `127.0.0.1:3000`.
- Chạy bằng systemd.
- Cloudflare Tunnel publish `radio.weddingngocthang.online`.
- Không mở port modem.
- Tắt sleep/suspend nếu máy là server.
- Khuyến nghị LAN, UPS và BIOS auto power-on.

## Lệnh kiểm tra môi trường không cần sudo

```bash
cat /etc/os-release
uname -a
lscpu
free -h
df -h
node -v || true
npm -v || true
git --version || true
systemctl --version
```

## Quy tắc Codex

Codex chỉ được tạo file và chạy build/test trong thư mục dự án. Mọi lệnh sudo, systemd, Cloudflare, DNS và firewall phải trình bày trước, giải thích và chờ xác nhận.
