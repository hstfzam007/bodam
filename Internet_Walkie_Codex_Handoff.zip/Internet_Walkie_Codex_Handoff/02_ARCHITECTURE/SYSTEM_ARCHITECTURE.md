# KIẾN TRÚC HỆ THỐNG

```text
Web PC / Android tương lai
        | HTTPS
        v
weddingngocthang.online (BKHOST)
        |-- Frontend tĩnh
        |-- PHP REST API
        |-- MySQL
        |
        | token/permission API
        v
radio.weddingngocthang.online
        |
Cloudflare Tunnel
        |
PC Linux Mint
        |-- Node.js TypeScript
        |-- WebSocket /ws
        |-- PTT coordinator
        |-- Audio relay
        |-- Presence
        |
        v
ESP32-S3 devices
```

## Phân trách nhiệm

### BKHOST

- Nguồn dữ liệu lâu dài.
- Tài khoản và quyền.
- Thiết bị, tên thiết bị, kênh.
- Lịch sử tin nhắn.
- OTA metadata/file.
- Không giữ stream audio.

### Linux Mint realtime

- Kết nối đang hoạt động.
- Presence tức thời.
- Khóa PTT theo kênh.
- Relay audio nhị phân.
- Không truy cập trực tiếp MySQL BKHOST nếu có thể; xác thực qua API.

### ESP32-S3

- I2S microphone và loa.
- PTT state machine.
- Jitter buffer.
- WSS reconnect.
- NVS.
- UI tối giản.

## Kiến trúc mã nguồn mục tiêu

```text
internet-walkie/
├── realtime-server/
├── web-hosting/
├── web-pc/
├── firmware-esp32s3/
├── deploy/
└── docs/
```
